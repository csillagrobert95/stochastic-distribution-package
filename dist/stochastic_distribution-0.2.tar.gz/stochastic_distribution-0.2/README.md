# stochastic-distribution

A python package for calculating mean and standard deviation
for Gaussian and Binomial distributions.